from PyQt5.QtCore import pyqtSlot
from PyQt5 import QtWidgets, QtGui
import os
import file_operate
import classes

from UI_changepass import UI_changepass
from UI_register import UI_register
from UI_admin import UI_admin
QMessageBox = QtWidgets.QMessageBox


class MainWindow(QtWidgets.QWidget, UI_register):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.modify.clicked.connect(self.jump_pass)
        self.login.clicked.connect(self.login_butt)

    def jump_pass(self):
        self.close()
        self.m2 = Window2()
        self.m2.show()

    def login_butt(self):
        id_p = self.id_input.text()
        pass_p = self.pass_input.text()
        iden = self.comboBox.currentText()
        if id_p != '' and pass_p != '':
            iden_all = {'普通用户': 'student', '厨师': 'staff', '管理员': 'admin'}
            if file_operate.login(id_p, pass_p, iden_all[iden]):
                if iden_all[iden] == 'admin':
                    self.close()
                    self.m2 = Window3()
                    self.m2.show()
                else:
                    QMessageBox.warning(self, '错误', 'student/staff还存在bug', QMessageBox.Yes, QMessageBox.Yes)
            else:
                QMessageBox.warning(self, '错误', '用户名和密码不匹配', QMessageBox.Yes, QMessageBox.Yes)
                self.pass_input.setText('')
        else:
            QMessageBox.warning(self, '错误', '用户名或密码未填写', QMessageBox.Yes, QMessageBox.Yes)


class Window2(QtWidgets.QDialog, UI_changepass):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        #insert your functions
        self.return_2.clicked.connect(self.close_pass)
        self.submit.clicked.connect(self.submit_pass)

    def close_pass(self):
        self.close()
        self.m2 = MainWindow()
        self.m2.show()

    def submit_pass(self):
        id_p = self.lineId.text()
        ori = self.lineOri.text()
        new = self.lineIdNew.text()
        conf = self.lineConf.text()
        identity = self.comboBox_2.currentText()
        if id_p == '' or ori == '' or new == '' or conf == '':
            QMessageBox.warning(self, '错误', '内容未填写', QMessageBox.Yes, QMessageBox.Yes)
        else:
            if new == conf:
                iden_all = {'普通用户': 'student', '厨师': 'staff', '管理员': 'admin'}
                if file_operate.change_pass(id_p, ori, new, iden_all[identity]):
                    QMessageBox.information(self, '提交成功', '密码已改', QMessageBox.Yes, QMessageBox.Yes)
                else:
                    QMessageBox.warning(self, '错误', '用户名或密码不正确', QMessageBox.Yes, QMessageBox.Yes)
            else:
                QMessageBox.warning(self, '错误', '密码确认不匹配', QMessageBox.Yes, QMessageBox.Yes)


class Window3(QtWidgets.QDialog, UI_admin):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        staff_dir = 'data/user_info/staff'
        student_dir = 'data/user_info/student'
        staff_files = os.listdir(staff_dir)
        student_files = os.listdir(student_dir)

        for staff in staff_files:
            self.staff.addItem(staff.replace('.pickle', ''))

        for student in student_files:
            self.student.addItem(student.replace('.pickle', ''))

        self.delete1.clicked.connect(self.delete_student)
        self.delete2.clicked.connect(self.delete_staff)
        self.toolButton.clicked.connect(self.create_acc)
        self.admini = classes.admin('', '', '')

    def delete_student(self):
        element = self.student.currentItem()
        eletext = element.text()
        reply = QMessageBox.warning(self, '警告', '确实要删除吗？', QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.admini.delete_stuaccount(eletext, 'student')
            element.setHidden(True)

    def delete_staff(self):
        element = self.staff.currentItem()
        eletext = element.text()
        reply = QMessageBox.warning(self, '警告', '确实要删除吗？', QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.admini.delete_stuffaccount(eletext, 'staff')
            element.setHidden(True)

    def create_acc(self):
        QMessageBox.warning(self, '错误', '您还不能造账号', QMessageBox.Yes, QMessageBox.Yes)




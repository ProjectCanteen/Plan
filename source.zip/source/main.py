from PyQt5 import QtWidgets
import sys

import action_all

MainWindow = action_all.MainWindow
app = QtWidgets.QApplication(sys.argv)
ui = MainWindow()
ui.show()
sys.exit(app.exec_())


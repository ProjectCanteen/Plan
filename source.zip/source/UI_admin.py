# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\zzy\Desktop\file\食堂点餐系统v0.6\source\used_uis\for_admin.ui'
#
# Created by: PyQt5 UI code generator 5.11.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class UI_admin(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(334, 472)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(40, 30, 261, 31))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(40, 110, 261, 18))
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(110, 70, 121, 18))
        self.label_3.setObjectName("label_3")
        self.student = QtWidgets.QListWidget(self.centralwidget)
        self.student.setGeometry(QtCore.QRect(30, 150, 131, 192))
        self.student.setObjectName("student")
        self.staff = QtWidgets.QListWidget(self.centralwidget)
        self.staff.setGeometry(QtCore.QRect(180, 150, 131, 192))
        self.staff.setObjectName("staff")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(30, 350, 81, 18))
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(180, 350, 81, 18))
        self.label_5.setObjectName("label_5")
        self.delete1 = QtWidgets.QToolButton(self.centralwidget)
        self.delete1.setGeometry(QtCore.QRect(110, 350, 52, 24))
        self.delete1.setObjectName("delete1")
        self.delete2 = QtWidgets.QToolButton(self.centralwidget)
        self.delete2.setGeometry(QtCore.QRect(260, 350, 52, 24))
        self.delete2.setObjectName("delete2")
        self.toolButton = QtWidgets.QToolButton(self.centralwidget)
        self.toolButton.setGeometry(QtCore.QRect(130, 390, 71, 24))
        self.toolButton.setObjectName("toolButton")
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 334, 30))
        self.menubar.setObjectName("menubar")
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "管理登陆界面"))
        self.label.setText(_translate("MainWindow", "欢迎，您正在以管理员身份登入"))
        self.label_2.setText(_translate("MainWindow", "您可以管理全体人员的账号信息"))
        self.label_3.setText(_translate("MainWindow", "Administrator"))
        self.label_4.setText(_translate("MainWindow", "学生"))
        self.label_5.setText(_translate("MainWindow", "员工"))
        self.delete1.setText(_translate("MainWindow", "删除"))
        self.delete2.setText(_translate("MainWindow", "删除"))
        self.toolButton.setText(_translate("MainWindow", "创建"))

